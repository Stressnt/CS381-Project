<?php
$pageTitle = 'Report Item';
require_once 'includes/header.php';

requireLogin();

$db = getDB();
$editId = (int)($_GET['edit'] ?? 0);
$item   = null;
$isEdit = false;

if ($editId > 0) {
    $stmt = $db->prepare('SELECT * FROM items WHERE id = ? LIMIT 1');
    $stmt->execute([$editId]);
    $item = $stmt->fetch();

    if (!$item || ($item['user_id'] !== $user['id'] && !isAdmin())) {
        setFlash('error', 'Item not found or access denied.');
        header('Location: dashboard.php'); exit;
    }
    $isEdit    = true;
    $pageTitle = 'Edit Item';
}

$categories = [
    'Electronics','Bags','ID / Cards','Keys','Accessories',
    'Books','Clothing','Sports','Documents','Other'
];

$errors = [];
$values = [
    'type'          => $item['type']          ?? 'lost',
    'title'         => $item['title']         ?? '',
    'description'   => $item['description']   ?? '',
    'category'      => $item['category']      ?? '',
    'location'      => $item['location']      ?? '',
    'date_occurred' => $item['date_occurred'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $type          = in_array($_POST['type'] ?? '', ['lost','found']) ? $_POST['type'] : 'lost';
    $title         = trim($_POST['title']         ?? '');
    $description   = trim($_POST['description']   ?? '');
    $category      = trim($_POST['category']      ?? '');
    $location      = trim($_POST['location']      ?? '');
    $date_occurred = trim($_POST['date_occurred'] ?? '');

    $values = compact('type','title','description','category','location','date_occurred');

    if (mb_strlen($title) < 3)           $errors[] = 'Title must be at least 3 characters.';
    if (mb_strlen($description) < 10)    $errors[] = 'Description must be at least 10 characters.';
    if (!in_array($category, $categories)) $errors[] = 'Please select a valid category.';
    if (mb_strlen($location) < 2)        $errors[] = 'Please enter the location.';
    if (!$date_occurred)                 $errors[] = 'Please select the date.';
    if ($date_occurred > date('Y-m-d'))  $errors[] = 'Date cannot be in the future.';

    $imageName = $item['image'] ?? null;
    if (!empty($_FILES['image']['name'])) {
        $file     = $_FILES['image'];
        $allowed  = ['image/jpeg','image/png','image/gif','image/webp'];
        $maxSize  = 2 * 1024 * 1024; // 2MB

        if (!in_array($file['type'], $allowed)) {
            $errors[] = 'Only JPG, PNG, GIF, or WEBP images are allowed.';
        } elseif ($file['size'] > $maxSize) {
            $errors[] = 'Image must be smaller than 2 MB.';
        } elseif ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Image upload failed. Please try again.';
        } else {
            $ext       = pathinfo($file['name'], PATHINFO_EXTENSION);
            $imageName = uniqid('item_', true) . '.' . strtolower($ext);
            $dest      = __DIR__ . '/uploads/items/' . $imageName;

            if (!move_uploaded_file($file['tmp_name'], $dest)) {
                $errors[] = 'Could not save the image. Check folder permissions.';
                $imageName = $item['image'] ?? null;
            }
        }
    }

    if (empty($errors)) {
        if ($isEdit) {
            $stmt = $db->prepare("
                UPDATE items SET type=?, title=?, description=?, category=?,
                                 location=?, date_occurred=?, image=?
                WHERE id=?
            ");
            $stmt->execute([$type,$title,$description,$category,$location,$date_occurred,$imageName,$editId]);
            setFlash('success', 'Item updated successfully.');
            header("Location: item-detail.php?id=$editId"); exit;
        } else {
            $stmt = $db->prepare("
                INSERT INTO items (user_id, type, title, description, category, location, date_occurred, image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$user['id'],$type,$title,$description,$category,$location,$date_occurred,$imageName]);
            $newId = (int)$db->lastInsertId();
            setFlash('success', 'Item reported successfully!');
            header("Location: item-detail.php?id=$newId"); exit;
        }
    }
}
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb">
                <a href="index.php">Home</a><span>/</span>
                <?= $isEdit ? '<a href="dashboard.php">Dashboard</a><span>/</span> Edit Item' : 'Report Item' ?>
            </div>
            <h1><?= $isEdit ? 'Edit Item' : 'Report an Item' ?></h1>
            <p><?= $isEdit ? 'Update the item details below.' : 'Report a lost or found item on campus.' ?></p>
        </div>
    </div>
</div>

<div class="container">
    <div class="form-card form-card-wide">
        <h2 class="form-title"><?= $isEdit ? 'Edit Item Details' : 'Report Lost or Found Item' ?></h2>

        <?php if (!empty($errors)): ?>
            <div class="flash flash-error" style="border-radius:8px;margin-bottom:20px">
                <i class="fas fa-exclamation-circle"></i>
                <ul style="margin:0;padding-left:16px">
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="reportForm" method="POST" enctype="multipart/form-data"
              action="report.php<?= $isEdit ? "?edit=$editId" : '' ?>" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

            
            <div class="form-group">
                <label>Item Type <span style="color:var(--danger)">*</span></label>
                <div class="type-toggle">
                    <label class="type-btn lost <?= $values['type'] === 'lost' ? 'selected' : '' ?>">
                        <input type="radio" name="type" value="lost"
                               <?= $values['type'] === 'lost' ? 'checked' : '' ?>>
                        <i class="fas fa-search"></i> I Lost Something
                    </label>
                    <label class="type-btn found <?= $values['type'] === 'found' ? 'selected' : '' ?>">
                        <input type="radio" name="type" value="found"
                               <?= $values['type'] === 'found' ? 'checked' : '' ?>>
                        <i class="fas fa-hand-holding"></i> I Found Something
                    </label>
                </div>
            </div>

            
            <div class="form-group">
                <label for="title">Item Title <span style="color:var(--danger)">*</span></label>
                <input type="text" id="title" name="title"
                       value="<?= e($values['title']) ?>"
                       placeholder="e.g. Black Laptop Bag, Samsung Galaxy Phone…"
                       required maxlength="150">
            </div>

            
            <div class="form-group">
                <label for="description">Description <span style="color:var(--danger)">*</span></label>
                <textarea id="description" name="description"
                          placeholder="Describe the item in detail – color, brand, model, distinctive marks, what was inside, etc."
                          required maxlength="1000" rows="5"><?= e($values['description']) ?></textarea>
            </div>

            
            <div class="form-row">
                <div class="form-group">
                    <label for="category">Category <span style="color:var(--danger)">*</span></label>
                    <select id="category" name="category" required>
                        <option value="">Select a category…</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= e($cat) ?>" <?= $values['category'] === $cat ? 'selected' : '' ?>>
                                <?= e($cat) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date_occurred">Date <?= $values['type'] === 'found' ? 'Found' : 'Lost' ?> <span style="color:var(--danger)">*</span></label>
                    <input type="date" id="date_occurred" name="date_occurred"
                           value="<?= e($values['date_occurred']) ?>"
                           max="<?= date('Y-m-d') ?>" required>
                </div>
            </div>

            
            <div class="form-group">
                <label for="location">Location on Campus <span style="color:var(--danger)">*</span></label>
                <input type="text" id="location" name="location"
                       value="<?= e($values['location']) ?>"
                       placeholder="e.g. Library – 2nd Floor, Canteen, Engineering Building Room 204…"
                       required maxlength="150">
            </div>

            
            <div class="form-group">
                <label>Photo <span style="color:var(--text-muted);font-weight:400">(optional, max 2MB)</span></label>
                <div class="file-upload-area">
                    <input type="file" id="itemImage" name="image"
                           accept="image/jpeg,image/png,image/gif,image/webp">
                    <div class="file-upload-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                    <p class="file-upload-text">
                        Click to upload or drag &amp; drop<br>
                        <small>JPG, PNG, GIF, WEBP — max 2 MB</small>
                    </p>
                </div>
                <?php if ($isEdit && $item['image']): ?>
                    <p class="field-hint">Current image:
                        <a href="uploads/items/<?= e($item['image']) ?>" target="_blank">View</a>
                        (upload a new image to replace)
                    </p>
                <?php endif; ?>
                <img id="imagePreview" src="" alt="Preview">
            </div>

            <div class="flex gap-8 mt-16" style="flex-wrap:wrap">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-<?= $isEdit ? 'save' : 'paper-plane' ?>"></i>
                    <?= $isEdit ? 'Save Changes' : 'Submit Report' ?>
                </button>
                <a href="<?= $isEdit ? "item-detail.php?id=$editId" : 'dashboard.php' ?>"
                   class="btn btn-outline">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
