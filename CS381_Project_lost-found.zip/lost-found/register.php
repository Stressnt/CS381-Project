<?php
$pageTitle = 'Register';
$bodyClass = 'auth-page';
require_once 'config/db.php';
require_once 'includes/auth.php';
startSession();

if (isLoggedIn()) { header('Location: index.php'); exit; }

$errors = [];
$values = ['name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $name     = trim($_POST['name']             ?? '');
    $email    = trim($_POST['email']            ?? '');
    $phone    = trim($_POST['phone']            ?? '');
    $password = $_POST['password']              ?? '';
    $confirm  = $_POST['confirm_password']      ?? '';

    $values = compact('name', 'email', 'phone');

    if (mb_strlen($name) < 2) {
        $errors[] = 'Full name must be at least 2 characters.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        $db = getDB();

        $check = $db->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'This email is already registered. Please login.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            $stmt = $db->prepare(
                'INSERT INTO users (name, email, password, phone) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute([$name, $email, $hash, $phone]);

            $userId = (int)$db->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user_id']   = $userId;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_role'] = 'student';

            setFlash('success', 'Account created! Welcome to YIC Lost & Found, ' . $name . '.');
            header('Location: dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | YIC Lost & Found</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
<nav class="navbar">
    <div class="nav-container">
        <a href="index.php" class="nav-brand">
            <i class="fas fa-search-location"></i>
            <span>YIC Lost &amp; Found</span>
        </a>
    </div>
</nav>

<main class="main-content" style="display:flex;align-items:center;justify-content:center;padding:40px 20px">
    <div class="auth-card" style="max-width:500px">
        <div class="auth-logo">
            <i class="fas fa-user-plus" style="color:var(--primary)"></i>
            <h1>Create Account</h1>
            <p>Join the YIC Lost &amp; Found community</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="flash flash-error" style="border-radius:8px;margin-bottom:20px">
                <i class="fas fa-exclamation-circle"></i>
                <ul style="margin:0;padding-left:16px">
                    <?php foreach ($errors as $err): ?>
                        <li><?= e($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="registerForm" method="POST" action="register.php" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">

            <div class="form-group">
                <label for="name">Full Name <span style="color:var(--danger)">*</span></label>
                <input type="text" id="name" name="name"
                       value="<?= e($values['name']) ?>"
                       placeholder="Ahmed Al-Ghamdi" required maxlength="100" autocomplete="name">
            </div>

            <div class="form-group">
                <label for="email">Email Address <span style="color:var(--danger)">*</span></label>
                <input type="email" id="email" name="email"
                       value="<?= e($values['email']) ?>"
                       placeholder="you@yic.edu.sa" required autocomplete="email">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number <span style="color:var(--text-muted);font-weight:400">(optional)</span></label>
                <input type="tel" id="phone" name="phone"
                       value="<?= e($values['phone']) ?>"
                       placeholder="05XXXXXXXX" maxlength="20">
            </div>

            <div class="form-group">
                <label for="password">Password <span style="color:var(--danger)">*</span></label>
                <div class="password-wrapper">
                    <input type="password" id="password" name="password"
                           placeholder="Minimum 8 characters" required autocomplete="new-password">
                    <button type="button" class="toggle-pw" aria-label="Toggle password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <p class="field-hint">At least 8 characters</p>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password <span style="color:var(--danger)">*</span></label>
                <div class="password-wrapper">
                    <input type="password" id="confirm_password" name="confirm_password"
                           placeholder="Repeat your password" required autocomplete="new-password">
                    <button type="button" class="toggle-pw" aria-label="Toggle password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-user-plus"></i> Create Account
            </button>
        </form>

        <div class="divider"><span>Already have an account?</span></div>
        <a href="login.php" class="btn btn-outline btn-block">
            <i class="fas fa-sign-in-alt"></i> Login
        </a>

        <p class="auth-link"><a href="index.php"><i class="fas fa-home"></i> Back to Home</a></p>
    </div>
</main>
<script src="js/main.js"></script>
</body>
</html>
