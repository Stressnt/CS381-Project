<?php
$root = defined('ADMIN_PAGE') ? '../' : '';
?>
</main>

<div class="rc-stripe"></div>
<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-brand">
            <i class="fas fa-search-location"></i>
            <span>YIC Lost &amp; Found Portal</span>
        </div>
        <p class="footer-sub">
            Yanbu Industrial College &mdash; CS381 Web Application Development
        </p>
        <p class="footer-copy">
            &copy; <?= date('Y') ?> Yanbu Industrial College. All rights reserved.
        </p>
    </div>
</footer>

<script src="<?= $root ?>js/main.js"></script>
</body>
</html>
