/* ============================================================
   main.js  –  YIC Lost & Found Portal
   Vanilla ES6 — No frameworks/libraries
   ============================================================ */

'use strict';

/* ── Dark Mode Toggle ───────────────────────────────────────── */
(function initDarkMode() {
    const btn  = document.getElementById('darkToggle');
    const html = document.documentElement;

    function apply(dark) {
        html.setAttribute('data-theme', dark ? 'dark' : 'light');
        if (!btn) return;
        btn.querySelector('i').className = dark ? 'fas fa-sun' : 'fas fa-moon';
        btn.setAttribute('title',      dark ? 'Switch to light mode' : 'Switch to dark mode');
        btn.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
    }

    // Sync icon with whatever the <head> script already applied
    apply(html.getAttribute('data-theme') === 'dark');

    if (!btn) return;
    btn.addEventListener('click', () => {
        const isDark = html.getAttribute('data-theme') === 'dark';
        localStorage.setItem('theme', isDark ? 'light' : 'dark');
        apply(!isDark);
    });
})();

/* ── Mobile Navigation Toggle ───────────────────────────────── */
(function initNav() {
    const toggle = document.getElementById('navToggle');
    const links  = document.getElementById('navLinks');
    if (!toggle || !links) return;

    toggle.addEventListener('click', () => {
        const open = links.classList.toggle('open');
        toggle.setAttribute('aria-expanded', open);
        toggle.querySelector('i').className = open ? 'fas fa-times' : 'fas fa-bars';
    });

    // Close on outside click
    document.addEventListener('click', e => {
        if (!toggle.contains(e.target) && !links.contains(e.target)) {
            links.classList.remove('open');
            toggle.querySelector('i').className = 'fas fa-bars';
        }
    });
})();

/* ── Auto-dismiss Flash Messages ────────────────────────────── */
(function autoFlash() {
    const flash = document.getElementById('flashMsg');
    if (!flash) return;
    setTimeout(() => {
        flash.style.transition = 'opacity .5s';
        flash.style.opacity = '0';
        setTimeout(() => flash.remove(), 500);
    }, 4000);
})();

/* ── Password Show/Hide Toggle ──────────────────────────────── */
document.querySelectorAll('.toggle-pw').forEach(btn => {
    btn.addEventListener('click', () => {
        const inp = btn.previousElementSibling;
        if (!inp) return;
        const isText = inp.type === 'text';
        inp.type = isText ? 'password' : 'text';
        btn.querySelector('i').className = isText ? 'fas fa-eye' : 'fas fa-eye-slash';
    });
});

/* ── Item Type Toggle (Lost / Found) ────────────────────────── */
(function initTypeToggle() {
    const btns = document.querySelectorAll('.type-btn');
    btns.forEach(btn => {
        btn.addEventListener('click', () => {
            btns.forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            const radio = btn.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });
    });

    // Mark initial selection
    btns.forEach(btn => {
        const radio = btn.querySelector('input[type="radio"]');
        if (radio && radio.checked) btn.classList.add('selected');
    });
})();

/* ── Image Preview on Upload ────────────────────────────────── */
(function initImagePreview() {
    const fileInput = document.getElementById('itemImage');
    const preview   = document.getElementById('imagePreview');
    if (!fileInput || !preview) return;

    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (!file) { preview.style.display = 'none'; return; }

        // Validate type & size client-side (2MB)
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            showFieldError(fileInput, 'Only JPG, PNG, GIF, or WEBP images are allowed.');
            fileInput.value = '';
            preview.style.display = 'none';
            return;
        }
        if (file.size > 2 * 1024 * 1024) {
            showFieldError(fileInput, 'Image must be smaller than 2 MB.');
            fileInput.value = '';
            preview.style.display = 'none';
            return;
        }

        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    });
})();

/* ── Client-side Form Validation ────────────────────────────── */
(function initFormValidation() {
    // Report Item form
    const reportForm = document.getElementById('reportForm');
    if (reportForm) {
        reportForm.addEventListener('submit', e => {
            let valid = true;
            clearErrors(reportForm);

            const title = reportForm.querySelector('#title');
            const desc  = reportForm.querySelector('#description');
            const loc   = reportForm.querySelector('#location');
            const date  = reportForm.querySelector('#date_occurred');
            const cat   = reportForm.querySelector('#category');

            if (!title || title.value.trim().length < 3) {
                showFieldError(title, 'Title must be at least 3 characters.'); valid = false;
            }
            if (!desc || desc.value.trim().length < 10) {
                showFieldError(desc, 'Description must be at least 10 characters.'); valid = false;
            }
            if (!loc || loc.value.trim().length < 2) {
                showFieldError(loc, 'Please enter the location.'); valid = false;
            }
            if (!date || !date.value) {
                showFieldError(date, 'Please select the date.'); valid = false;
            }
            if (!cat || cat.value === '') {
                showFieldError(cat, 'Please select a category.'); valid = false;
            }

            if (!valid) e.preventDefault();
        });
    }

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', e => {
            clearErrors(loginForm);
            let valid = true;
            const email    = loginForm.querySelector('#email');
            const password = loginForm.querySelector('#password');

            if (!email || !isValidEmail(email.value)) {
                showFieldError(email, 'Please enter a valid email.'); valid = false;
            }
            if (!password || password.value.length < 1) {
                showFieldError(password, 'Password is required.'); valid = false;
            }
            if (!valid) e.preventDefault();
        });
    }

    // Register form
    const regForm = document.getElementById('registerForm');
    if (regForm) {
        regForm.addEventListener('submit', e => {
            clearErrors(regForm);
            let valid = true;
            const name    = regForm.querySelector('#name');
            const email   = regForm.querySelector('#email');
            const pass    = regForm.querySelector('#password');
            const confirm = regForm.querySelector('#confirm_password');

            if (!name || name.value.trim().length < 2) {
                showFieldError(name, 'Full name must be at least 2 characters.'); valid = false;
            }
            if (!email || !isValidEmail(email.value)) {
                showFieldError(email, 'Please enter a valid @yic.edu.sa email.'); valid = false;
            }
            if (!pass || pass.value.length < 8) {
                showFieldError(pass, 'Password must be at least 8 characters.'); valid = false;
            }
            if (confirm && pass && confirm.value !== pass.value) {
                showFieldError(confirm, 'Passwords do not match.'); valid = false;
            }
            if (!valid) e.preventDefault();
        });
    }

    // Claim form
    const claimForm = document.getElementById('claimForm');
    if (claimForm) {
        claimForm.addEventListener('submit', e => {
            clearErrors(claimForm);
            const msg = claimForm.querySelector('#claim_message');
            if (!msg || msg.value.trim().length < 10) {
                showFieldError(msg, 'Please provide at least 10 characters explaining your claim.');
                e.preventDefault();
            }
        });
    }
})();

/* ── Helpers ────────────────────────────────────────────────── */
function showFieldError(field, msg) {
    if (!field) return;
    field.style.borderColor = '#ef4444';
    let err = field.parentElement.querySelector('.field-error');
    if (!err) {
        err = document.createElement('p');
        err.className = 'field-error';
        field.parentElement.appendChild(err);
    }
    err.textContent = msg;
}

function clearErrors(form) {
    form.querySelectorAll('.field-error').forEach(el => el.remove());
    form.querySelectorAll('input, textarea, select').forEach(el => {
        el.style.borderColor = '';
    });
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/* ── Confirm Delete / Action ────────────────────────────────── */
document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
        if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
});

/* ── Smooth scroll anchors ──────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const target = document.querySelector(a.getAttribute('href'));
        if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
    });
});

/* ── Character counter for textareas ────────────────────────── */
document.querySelectorAll('textarea[maxlength]').forEach(ta => {
    const max = parseInt(ta.getAttribute('maxlength'));
    const counter = document.createElement('p');
    counter.className = 'field-hint';
    counter.textContent = `0 / ${max} characters`;
    ta.insertAdjacentElement('afterend', counter);
    ta.addEventListener('input', () => {
        counter.textContent = `${ta.value.length} / ${max} characters`;
        counter.style.color = ta.value.length > max * 0.9 ? '#f59e0b' : '';
    });
});
