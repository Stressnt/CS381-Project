<?php
$pageTitle = 'Browse Items';
require_once 'includes/header.php';

$db = getDB();

$search   = trim($_GET['search']   ?? '');
$type     = $_GET['type']          ?? '';
$category = $_GET['category']      ?? '';
$status   = $_GET['status']        ?? 'active';
$sort     = $_GET['sort']          ?? 'newest';

$perPage = 9;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where  = [];
$params = [];

if ($search !== '') {
    $where[]  = '(i.title LIKE ? OR i.description LIKE ? OR i.location LIKE ?)';
    $like     = "%$search%";
    $params   = array_merge($params, [$like, $like, $like]);
}
if (in_array($type, ['lost', 'found'])) {
    $where[]  = 'i.type = ?';
    $params[] = $type;
}
if ($category !== '') {
    $where[]  = 'i.category = ?';
    $params[] = $category;
}
if (in_array($status, ['active', 'claimed', 'closed'])) {
    $where[]  = 'i.status = ?';
    $params[] = $status;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$orderSQL = match ($sort) {
    'oldest' => 'ORDER BY i.created_at ASC',
    'a-z'    => 'ORDER BY i.title ASC',
    default  => 'ORDER BY i.created_at DESC',
};

// Count total
$countStmt = $db->prepare("SELECT COUNT(*) FROM items i $whereSQL");
$countStmt->execute($params);
$total     = (int)$countStmt->fetchColumn();
$totalPages = (int)ceil($total / $perPage);

// Fetch items
$stmt = $db->prepare("
    SELECT i.*, u.name AS reporter_name
    FROM items i
    JOIN users u ON u.id = i.user_id
    $whereSQL $orderSQL
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$items = $stmt->fetchAll();

// Categories for filter dropdown
$categories = [
    'Electronics','Bags','ID / Cards','Keys','Accessories',
    'Books','Clothing','Sports','Documents','Other'
];

$catIcons = [
    'Electronics' => 'fas fa-laptop',   'Bags'    => 'fas fa-briefcase',
    'ID / Cards'  => 'fas fa-id-card',  'Keys'    => 'fas fa-key',
    'Accessories' => 'fas fa-glasses',  'Books'   => 'fas fa-book',
    'Clothing'    => 'fas fa-tshirt',   'Sports'  => 'fas fa-football-ball',
    'Documents'   => 'fas fa-file-alt', 'Other'   => 'fas fa-box',
];

// Build query string helper for pagination
function buildQuery(array $overrides = []): string {
    $params = array_merge([
        'search'   => $_GET['search']   ?? '',
        'type'     => $_GET['type']     ?? '',
        'category' => $_GET['category'] ?? '',
        'status'   => $_GET['status']   ?? 'active',
        'sort'     => $_GET['sort']     ?? 'newest',
    ], $overrides);
    return http_build_query(array_filter($params, fn($v) => $v !== ''));
}
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb">
                <a href="index.php">Home</a>
                <span>/</span> Browse Items
            </div>
            <h1>Browse Items</h1>
            <p><?= $total ?> item<?= $total !== 1 ? 's' : '' ?> found</p>
        </div>
        <?php if (isLoggedIn()): ?>
        <a href="report.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Report Item
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="container" style="padding-top:28px;padding-bottom:48px">

    
    <form method="GET" action="items.php" id="filterForm">
        <div class="filter-bar">
            <div class="search-input-wrap">
                <i class="fas fa-search"></i>
                <input type="text" name="search" value="<?= e($search) ?>"
                       placeholder="Search by title, description, location…">
            </div>
            <div class="form-group">
                <label>Type</label>
                <select name="type" onchange="this.form.submit()">
                    <option value="">All Types</option>
                    <option value="lost"  <?= $type === 'lost'  ? 'selected' : '' ?>>Lost</option>
                    <option value="found" <?= $type === 'found' ? 'selected' : '' ?>>Found</option>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= e($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
                            <?= e($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" onchange="this.form.submit()">
                    <option value="">All Status</option>
                    <option value="active"  <?= $status === 'active'  ? 'selected' : '' ?>>Active</option>
                    <option value="claimed" <?= $status === 'claimed' ? 'selected' : '' ?>>Claimed</option>
                    <option value="closed"  <?= $status === 'closed'  ? 'selected' : '' ?>>Closed</option>
                </select>
            </div>
            <div class="form-group">
                <label>Sort By</label>
                <select name="sort" onchange="this.form.submit()">
                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest First</option>
                    <option value="oldest" <?= $sort === 'oldest' ? 'selected' : '' ?>>Oldest First</option>
                    <option value="a-z"    <?= $sort === 'a-z'    ? 'selected' : '' ?>>A – Z</option>
                </select>
            </div>
            <div>
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
            <?php if ($search || $type || $category || $status !== 'active'): ?>
            <div>
                <label>&nbsp;</label>
                <a href="items.php" class="btn btn-outline">
                    <i class="fas fa-times"></i> Clear
                </a>
            </div>
            <?php endif; ?>
        </div>
    </form>

    
    <?php if (empty($items)): ?>
        <div class="empty-state">
            <i class="fas fa-search-minus"></i>
            <h3>No items found</h3>
            <p>Try adjusting your filters or search terms.</p>
            <a href="items.php" class="btn btn-primary">Clear Filters</a>
        </div>
    <?php else: ?>
        <div class="grid-3">
            <?php foreach ($items as $item):
                $icon = $catIcons[$item['category']] ?? 'fas fa-box';
            ?>
            <article class="card">
                <?php if ($item['image']): ?>
                    <img src="uploads/items/<?= e($item['image']) ?>"
                         alt="<?= e($item['title']) ?>" class="card-img">
                <?php else: ?>
                    <div class="card-img-placeholder"><i class="<?= $icon ?>"></i></div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="flex items-center gap-8 mb-8" style="flex-wrap:wrap">
                        <span class="badge-<?= $item['type'] ?>"><?= ucfirst($item['type']) ?></span>
                        <span class="badge-<?= $item['status'] ?>"><?= ucfirst($item['status']) ?></span>
                    </div>
                    <h3 class="card-title"><?= e($item['title']) ?></h3>
                    <p class="card-text">
                        <?= e(mb_strimwidth($item['description'], 0, 80, '…')) ?>
                    </p>
                    <div style="display:flex;flex-direction:column;gap:4px;font-size:.8rem;color:var(--text-muted)">
                        <span><i class="fas fa-tag"></i> <?= e($item['category']) ?></span>
                        <span><i class="fas fa-map-marker-alt"></i> <?= e($item['location']) ?></span>
                        <span><i class="fas fa-calendar"></i> <?= date('d M Y', strtotime($item['date_occurred'])) ?></span>
                    </div>
                </div>
                <div class="card-footer flex items-center justify-between">
                    <span style="font-size:.78rem;color:var(--text-muted)">
                        by <?= e($item['reporter_name']) ?>
                    </span>
                    <a href="item-detail.php?id=<?= $item['id'] ?>" class="btn btn-primary btn-sm">
                        Details <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>

        
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?<?= buildQuery(['page' => $page - 1]) ?>">
                    <i class="fas fa-chevron-left"></i> Prev
                </a>
            <?php else: ?>
                <span class="disabled"><i class="fas fa-chevron-left"></i> Prev</span>
            <?php endif; ?>

            <?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): ?>
                <?php if ($p === $page): ?>
                    <span class="current"><?= $p ?></span>
                <?php else: ?>
                    <a href="?<?= buildQuery(['page' => $p]) ?>"><?= $p ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($page < $totalPages): ?>
                <a href="?<?= buildQuery(['page' => $page + 1]) ?>">
                    Next <i class="fas fa-chevron-right"></i>
                </a>
            <?php else: ?>
                <span class="disabled">Next <i class="fas fa-chevron-right"></i></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
