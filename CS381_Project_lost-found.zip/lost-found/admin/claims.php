<?php

define('ADMIN_PAGE', true);
$pageTitle = 'Manage Claims';
require_once '../includes/header.php';
requireAdmin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $claimId   = (int)($_POST['claim_id']   ?? 0);
    $action    = $_POST['action']            ?? '';
    $adminNote = trim($_POST['admin_note']   ?? '');

    if ($claimId > 0 && in_array($action, ['approve', 'reject'])) {
        $newStatus = $action === 'approve' ? 'approved' : 'rejected';

       
        $db->prepare(
            'UPDATE claims SET status = ?, admin_note = ? WHERE id = ?'
        )->execute([$newStatus, $adminNote, $claimId]);

        
        $cl = $db->prepare('SELECT cl.*, i.title AS item_title, i.id AS item_id
                             FROM claims cl
                             JOIN items i ON i.id = cl.item_id
                             WHERE cl.id = ?');
        $cl->execute([$claimId]);
        $claim = $cl->fetch();

        if ($claim) {
           
            if ($newStatus === 'approved') {
                $db->prepare("UPDATE items SET status = 'claimed' WHERE id = ?")->execute([$claim['item_id']]);
                $db->prepare("UPDATE claims SET status='rejected', admin_note='Another claim was approved for this item.'
                               WHERE item_id = ? AND id != ? AND status = 'pending'"
                )->execute([$claim['item_id'], $claimId]);
            }

           
            $msg = $newStatus === 'approved'
                ? 'Your claim for "' . $claim['item_title'] . '" has been APPROVED! Please visit the admin office to collect it.'
                : 'Your claim for "' . $claim['item_title'] . '" has been rejected.' . ($adminNote ? ' Note: ' . $adminNote : '');

            createNotification($claim['claimant_id'], $msg, '../item-detail.php?id=' . $claim['item_id']);
        }

        setFlash('success', 'Claim ' . $newStatus . ' successfully.');
        header('Location: claims.php'); exit;
    }
}

$statusFilter = $_GET['status'] ?? '';

$where  = $statusFilter ? 'WHERE cl.status = ?' : '';
$params = $statusFilter ? [$statusFilter] : [];

$claims = $db->prepare("
    SELECT cl.*, i.title AS item_title, i.type AS item_type, i.id AS item_id,
           u.name AS claimant_name, u.email AS claimant_email,
           r.name AS reporter_name
    FROM claims cl
    JOIN items i ON i.id = cl.item_id
    JOIN users u ON u.id = cl.claimant_id
    JOIN users r ON r.id = i.user_id
    $where
    ORDER BY FIELD(cl.status,'pending','approved','rejected'), cl.created_at DESC
");
$claims->execute($params);
$claimsList = $claims->fetchAll();

$pendingCount = (int)$db->query("SELECT COUNT(*) FROM claims WHERE status='pending'")->fetchColumn();
?>

<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <span><i class="fas fa-shield-alt"></i> Admin Panel</span>
            <small>YIC Lost &amp; Found</small>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="items.php"><i class="fas fa-list"></i> Manage Items</a>
            <a href="claims.php" class="active">
                <i class="fas fa-hand-paper"></i> Manage Claims
                <?php if ($pendingCount > 0): ?>
                    <span class="badge" style="margin-left:auto"><?= $pendingCount ?></span>
                <?php endif; ?>
            </a>
            <a href="users.php"><i class="fas fa-users"></i> Manage Users</a>
            <a href="../index.php"><i class="fas fa-globe"></i> View Site</a>
            <a href="../logout.php" style="color:#f87171"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </aside>

    <div class="admin-main">
        <div class="admin-header">
            <h1>Manage Claims</h1>
            <p>Review, approve, or reject item claims from students.</p>
        </div>

    
        <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
            <?php
            $tabs = ['' => 'All', 'pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];
            foreach ($tabs as $val => $label):
            ?>
            <a href="claims.php<?= $val ? "?status=$val" : '' ?>"
               class="btn btn-sm <?= $statusFilter === $val ? 'btn-primary' : 'btn-outline' ?>">
                <?= $label ?>
                <?php if ($val === 'pending' && $pendingCount > 0): ?>
                    <span class="badge"><?= $pendingCount ?></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>

        <?php if (empty($claimsList)): ?>
            <div class="empty-state" style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius)">
                <i class="fas fa-hand-paper"></i>
                <h3>No claims found</h3>
                <p>There are no <?= $statusFilter ?> claims to display.</p>
            </div>
        <?php else: ?>

        <?php foreach ($claimsList as $cl): ?>
        <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);margin-bottom:16px;overflow:hidden">
    
            <div style="padding:16px 20px;background:var(--bg);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
                <div>
                    <span class="badge-<?= $cl['item_type'] ?>" style="margin-right:8px">
                        <?= ucfirst($cl['item_type']) ?>
                    </span>
                    <a href="../item-detail.php?id=<?= $cl['item_id'] ?>" style="font-weight:700;font-size:1rem">
                        <?= e($cl['item_title']) ?>
                    </a>
                    <span style="color:var(--text-muted);font-size:.82rem;margin-left:8px">
                        reported by <?= e($cl['reporter_name']) ?>
                    </span>
                </div>
                <span class="badge-<?= $cl['status'] ?>" style="font-size:.85rem;padding:6px 14px">
                    <?= ucfirst($cl['status']) ?>
                </span>
            </div>

            
            <div style="padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:24px" class="claim-body">
                <div>
                    <h4 style="font-size:.85rem;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:8px">
                        Claimant
                    </h4>
                    <p style="font-weight:600"><?= e($cl['claimant_name']) ?></p>
                    <p style="font-size:.85rem;color:var(--text-muted)"><?= e($cl['claimant_email']) ?></p>
                    <p style="font-size:.82rem;color:var(--text-muted);margin-top:4px">
                        <i class="fas fa-clock"></i>
                        Submitted: <?= date('d M Y, h:i A', strtotime($cl['created_at'])) ?>
                    </p>
                </div>
                <div>
                    <h4 style="font-size:.85rem;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);margin-bottom:8px">
                        Claim Message
                    </h4>
                    <p style="font-size:.9rem;line-height:1.6"><?= e($cl['message']) ?></p>
                </div>
            </div>

            <?php if ($cl['admin_note']): ?>
            <div style="padding:12px 20px;background:var(--warning-bg);border-top:1px solid var(--border);font-size:.88rem">
                <i class="fas fa-sticky-note" style="color:var(--warning)"></i>
                <strong>Admin Note:</strong> <?= e($cl['admin_note']) ?>
            </div>
            <?php endif; ?>

            
            <?php if ($cl['status'] === 'pending'): ?>
            <div style="padding:16px 20px;border-top:1px solid var(--border);background:var(--bg)">
                <form method="POST" action="claims.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
                    <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                    <input type="hidden" name="claim_id" value="<?= $cl['id'] ?>">

                    <div class="form-group" style="margin-bottom:0;flex:1;min-width:200px">
                        <label style="font-size:.82rem">Admin Note (optional)</label>
                        <input type="text" name="admin_note" placeholder="Add a note to the claimant…" maxlength="200">
                    </div>

                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm"
                            data-confirm="Approve this claim? The item will be marked as claimed.">
                        <i class="fas fa-check"></i> Approve
                    </button>
                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm"
                            data-confirm="Reject this claim?">
                        <i class="fas fa-times"></i> Reject
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>

    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
