<?php
$pageTitle = 'Home';
require_once 'includes/header.php';

$db = getDB();

$stats = $db->query("
    SELECT
        SUM(type = 'lost')   AS total_lost,
        SUM(type = 'found')  AS total_found,
        SUM(status = 'claimed') AS total_claimed,
        COUNT(*)             AS total_items
    FROM items
")->fetch();

$recent = $db->query("
    SELECT i.*, u.name AS reporter_name
    FROM items i
    JOIN users u ON u.id = i.user_id
    WHERE i.status = 'active'
    ORDER BY i.created_at DESC
    LIMIT 6
")->fetchAll();

$catIcons = [
    'Electronics' => 'fas fa-laptop',
    'Bags'        => 'fas fa-briefcase',
    'ID / Cards'  => 'fas fa-id-card',
    'Keys'        => 'fas fa-key',
    'Accessories' => 'fas fa-glasses',
    'Books'       => 'fas fa-book',
    'Clothing'    => 'fas fa-tshirt',
    'Sports'      => 'fas fa-football-ball',
    'Documents'   => 'fas fa-file-alt',
    'Other'       => 'fas fa-box',
];
?>

<section class="hero">
    <div class="hero-content container">
        <h1><i class="fas fa-search-location"></i> YIC Lost &amp; Found Portal</h1>
        <p>Reuniting the Yanbu Industrial College community with their belongings. Report lost items, post found ones, and make claims — all in one place.</p>
        <div class="hero-actions">
            <a href="items.php" class="btn btn-white">
                <i class="fas fa-list"></i> Browse Items
            </a>
            <?php if (isLoggedIn()): ?>
                <a href="report.php" class="btn btn-accent">
                    <i class="fas fa-plus-circle"></i> Report an Item
                </a>
            <?php else: ?>
                <a href="register.php" class="btn btn-accent">
                    <i class="fas fa-user-plus"></i> Get Started
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="stats-bar">
    <div class="stats-bar-inner">
        <div class="stat-item">
            <div class="stat-num"><?= (int)$stats['total_items'] ?></div>
            <div class="stat-lbl">Total Reports</div>
        </div>
        <div class="stat-item">
            <div class="stat-num" style="color:var(--danger)"><?= (int)$stats['total_lost'] ?></div>
            <div class="stat-lbl">Items Lost</div>
        </div>
        <div class="stat-item">
            <div class="stat-num" style="color:var(--success)"><?= (int)$stats['total_found'] ?></div>
            <div class="stat-lbl">Items Found</div>
        </div>
        <div class="stat-item">
            <div class="stat-num" style="color:var(--accent)"><?= (int)$stats['total_claimed'] ?></div>
            <div class="stat-lbl">Successfully Claimed</div>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="section-header">
            <div>
                <h2 class="section-title">Recent Items</h2>
                <p class="section-sub">Latest lost &amp; found reports on campus</p>
            </div>
            <a href="items.php" class="btn btn-outline btn-sm">
                View All <i class="fas fa-arrow-right"></i>
            </a>
        </div>

        <?php if (empty($recent)): ?>
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>No items yet</h3>
                <p>Be the first to report a lost or found item.</p>
                <?php if (isLoggedIn()): ?>
                    <a href="report.php" class="btn btn-primary">Report Item</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="grid-3">
                <?php foreach ($recent as $item):
                    $catIcon = $catIcons[$item['category']] ?? 'fas fa-box';
                ?>
                <article class="card">
                    <?php if ($item['image']): ?>
                        <img src="uploads/items/<?= e($item['image']) ?>"
                             alt="<?= e($item['title']) ?>" class="card-img">
                    <?php else: ?>
                        <div class="card-img-placeholder">
                            <i class="<?= $catIcon ?>"></i>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="flex items-center gap-8 mb-8">
                            <span class="badge-<?= $item['type'] ?>"><?= ucfirst($item['type']) ?></span>
                            <span class="text-muted" style="font-size:.78rem">
                                <i class="fas fa-tag"></i> <?= e($item['category']) ?>
                            </span>
                        </div>
                        <h3 class="card-title"><?= e($item['title']) ?></h3>
                        <p class="card-text">
                            <?= e(mb_strimwidth($item['description'], 0, 90, '…')) ?>
                        </p>
                        <div class="flex items-center gap-8" style="font-size:.8rem;color:var(--text-muted)">
                            <span><i class="fas fa-map-marker-alt"></i> <?= e($item['location']) ?></span>
                        </div>
                    </div>
                    <div class="card-footer flex items-center justify-between">
                        <span style="font-size:.78rem;color:var(--text-muted)">
                            <i class="fas fa-clock"></i>
                            <?= date('d M Y', strtotime($item['created_at'])) ?>
                        </span>
                        <a href="item-detail.php?id=<?= $item['id'] ?>" class="btn btn-primary btn-sm">
                            View <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="section section-alt">
    <div class="container">
        <h2 class="section-title text-center">Browse by Category</h2>
        <p class="section-sub text-center">Find items quickly by selecting a category</p>
        <div class="cat-grid">
            <?php foreach ($catIcons as $cat => $icon): ?>
            <a href="items.php?category=<?= urlencode($cat) ?>" class="cat-card">
                <i class="<?= $icon ?>"></i>
                <span><?= e($cat) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container text-center">
        <h2 class="section-title">How It Works</h2>
        <p class="section-sub">Simple steps to recover your belongings</p>
        <div class="grid-3" style="margin-top:32px">
            <div class="card" style="padding:32px 24px;text-align:center;border:none;background:transparent">
                <div style="width:72px;height:72px;background:var(--primary-light);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:1.8rem;color:var(--primary)">
                    <i class="fas fa-edit"></i>
                </div>
                <h3 style="margin-bottom:10px;font-size:1.1rem">1. Report</h3>
                <p style="color:var(--text-muted);font-size:.9rem">Submit a detailed report of your lost item or something you found on campus.</p>
            </div>
            <div class="card" style="padding:32px 24px;text-align:center;border:none;background:transparent">
                <div style="width:72px;height:72px;background:var(--success-bg);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:1.8rem;color:var(--success)">
                    <i class="fas fa-search"></i>
                </div>
                <h3 style="margin-bottom:10px;font-size:1.1rem">2. Browse &amp; Claim</h3>
                <p style="color:var(--text-muted);font-size:.9rem">Search through found items and submit a claim with proof of ownership.</p>
            </div>
            <div class="card" style="padding:32px 24px;text-align:center;border:none;background:transparent">
                <div style="width:72px;height:72px;background:var(--warning-bg);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:1.8rem;color:var(--warning)">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3 style="margin-bottom:10px;font-size:1.1rem">3. Recover</h3>
                <p style="color:var(--text-muted);font-size:.9rem">Admin reviews and approves your claim. Collect your item from the admin office.</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
