<?php
$pageTitle = 'My Dashboard';
require_once 'includes/header.php';
requireLogin();

$db  = getDB();
$uid = $user['id'];

$myItems  = $db->prepare('SELECT COUNT(*) FROM items  WHERE user_id = ?'); $myItems->execute([$uid]);
$myClaims = $db->prepare('SELECT COUNT(*) FROM claims WHERE claimant_id = ?'); $myClaims->execute([$uid]);
$myActive = $db->prepare("SELECT COUNT(*) FROM items WHERE user_id = ? AND status='active'"); $myActive->execute([$uid]);
$myFound  = $db->prepare("SELECT COUNT(*) FROM items WHERE user_id = ? AND type='found'"); $myFound->execute([$uid]);

$tab = $_GET['tab'] ?? 'items';

$myItemsList = $db->prepare("
    SELECT i.*, (SELECT COUNT(*) FROM claims c WHERE c.item_id = i.id) AS claim_count
    FROM items i
    WHERE i.user_id = ?
    ORDER BY i.created_at DESC
");
$myItemsList->execute([$uid]);
$itemsList = $myItemsList->fetchAll();

$myClaimsList = $db->prepare("
    SELECT cl.*, i.title AS item_title, i.type AS item_type, i.status AS item_status, i.id AS item_id
    FROM claims cl
    JOIN items i ON i.id = cl.item_id
    WHERE cl.claimant_id = ?
    ORDER BY cl.created_at DESC
");
$myClaimsList->execute([$uid]);
$claimsList = $myClaimsList->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_item') {
    verifyCsrf();
    $deleteId = (int)($_POST['item_id'] ?? 0);
    $chk = $db->prepare('SELECT id FROM items WHERE id = ? AND user_id = ?');
    $chk->execute([$deleteId, $uid]);
    if ($chk->fetch()) {
        $db->prepare('DELETE FROM items WHERE id = ?')->execute([$deleteId]);
        setFlash('success', 'Item deleted successfully.');
    }
    header('Location: dashboard.php?tab=items'); exit;
}
?>

<div class="page-header">
    <div class="page-header-inner">
        <div>
            <div class="breadcrumb"><a href="index.php">Home</a><span>/</span> Dashboard</div>
            <h1>My Dashboard</h1>
            <p>Manage your items and claims</p>
        </div>
        <a href="report.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Report New Item
        </a>
    </div>
</div>

<div class="container">
    <div class="dashboard-grid">
        
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-avatar"><i class="fas fa-user"></i></div>
                <div class="sidebar-name"><?= e($user['name']) ?></div>
                <div class="sidebar-role">Student</div>
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php?tab=items"
                   class="<?= $tab === 'items' ? 'active' : '' ?>">
                    <i class="fas fa-list"></i> My Items
                </a>
                <a href="dashboard.php?tab=claims"
                   class="<?= $tab === 'claims' ? 'active' : '' ?>">
                    <i class="fas fa-hand-paper"></i> My Claims
                </a>
                <a href="notifications.php">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if ($notifCount > 0): ?>
                        <span class="badge" style="margin-left:auto"><?= $notifCount ?></span>
                    <?php endif; ?>
                </a>
                <a href="items.php">
                    <i class="fas fa-search"></i> Browse Items
                </a>
                <a href="report.php">
                    <i class="fas fa-plus-circle"></i> Report Item
                </a>
            </nav>
        </aside>

        
        <div>
            
            <div class="dash-stats">
                <div class="dash-stat">
                    <div class="dash-stat-icon blue"><i class="fas fa-list"></i></div>
                    <div>
                        <div class="dash-stat-num"><?= $myItems->fetchColumn() ?: (int)$db->query("SELECT COUNT(*) FROM items WHERE user_id=$uid")->fetchColumn() ?></div>
                        <div class="dash-stat-lbl">Total Reports</div>
                    </div>
                </div>
                <div class="dash-stat">
                    <div class="dash-stat-icon green"><i class="fas fa-check-circle"></i></div>
                    <div>
                        <div class="dash-stat-num"><?= (int)$db->query("SELECT COUNT(*) FROM items WHERE user_id=$uid AND status='active'")->fetchColumn() ?></div>
                        <div class="dash-stat-lbl">Active Items</div>
                    </div>
                </div>
                <div class="dash-stat">
                    <div class="dash-stat-icon yellow"><i class="fas fa-hand-paper"></i></div>
                    <div>
                        <div class="dash-stat-num"><?= (int)$db->query("SELECT COUNT(*) FROM claims WHERE claimant_id=$uid")->fetchColumn() ?></div>
                        <div class="dash-stat-lbl">My Claims</div>
                    </div>
                </div>
            </div>

            
            <?php if ($tab === 'items'): ?>
            <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
                <div style="padding:20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
                    <h2 style="font-size:1.1rem;font-weight:700">
                        <i class="fas fa-list" style="color:var(--primary)"></i> My Reported Items
                    </h2>
                </div>
                <?php if (empty($itemsList)): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No items yet</h3>
                        <p>You haven't reported any items.</p>
                        <a href="report.php" class="btn btn-primary">Report Your First Item</a>
                    </div>
                <?php else: ?>
                    <div class="table-wrap" style="border:none;border-radius:0">
                        <table>
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Type</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Claims</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($itemsList as $it): ?>
                                <tr>
                                    <td>
                                        <a href="item-detail.php?id=<?= $it['id'] ?>" style="font-weight:600">
                                            <?= e(mb_strimwidth($it['title'], 0, 40, '…')) ?>
                                        </a>
                                        <br>
                                        <small style="color:var(--text-muted)">
                                            <?= e(mb_strimwidth($it['location'], 0, 30, '…')) ?>
                                        </small>
                                    </td>
                                    <td><span class="badge-<?= $it['type'] ?>"><?= ucfirst($it['type']) ?></span></td>
                                    <td><?= e($it['category']) ?></td>
                                    <td><span class="badge-<?= $it['status'] ?>"><?= ucfirst($it['status']) ?></span></td>
                                    <td>
                                        <?php if ($it['claim_count'] > 0): ?>
                                            <span class="badge" style="background:var(--primary)">
                                                <?= $it['claim_count'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color:var(--text-muted)">0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d M Y', strtotime($it['created_at'])) ?></td>
                                    <td>
                                        <div class="flex gap-8">
                                            <a href="report.php?edit=<?= $it['id'] ?>" class="btn btn-outline btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form method="POST" action="dashboard.php" style="display:inline">
                                                <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
                                                <input type="hidden" name="action" value="delete_item">
                                                <input type="hidden" name="item_id" value="<?= $it['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                        data-confirm="Delete this item? This cannot be undone.">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            
            <?php elseif ($tab === 'claims'): ?>
            <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
                <div style="padding:20px;border-bottom:1px solid var(--border)">
                    <h2 style="font-size:1.1rem;font-weight:700">
                        <i class="fas fa-hand-paper" style="color:var(--primary)"></i> My Claims
                    </h2>
                </div>
                <?php if (empty($claimsList)): ?>
                    <div class="empty-state">
                        <i class="fas fa-hand-paper"></i>
                        <h3>No claims yet</h3>
                        <p>You haven't submitted any claims. Browse found items to claim yours.</p>
                        <a href="items.php?type=found" class="btn btn-primary">Browse Found Items</a>
                    </div>
                <?php else: ?>
                    <div class="table-wrap" style="border:none;border-radius:0">
                        <table>
                            <thead>
                                <tr>
                                    <th>Item Claimed</th>
                                    <th>Type</th>
                                    <th>Claim Status</th>
                                    <th>Admin Note</th>
                                    <th>Submitted</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($claimsList as $cl): ?>
                                <tr>
                                    <td>
                                        <a href="item-detail.php?id=<?= $cl['item_id'] ?>" style="font-weight:600">
                                            <?= e(mb_strimwidth($cl['item_title'], 0, 40, '…')) ?>
                                        </a>
                                    </td>
                                    <td><span class="badge-<?= $cl['item_type'] ?>"><?= ucfirst($cl['item_type']) ?></span></td>
                                    <td><span class="badge-<?= $cl['status'] ?>"><?= ucfirst($cl['status']) ?></span></td>
                                    <td>
                                        <?php if ($cl['admin_note']): ?>
                                            <span style="font-size:.82rem"><?= e($cl['admin_note']) ?></span>
                                        <?php else: ?>
                                            <span style="color:var(--text-muted);font-size:.82rem">–</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d M Y', strtotime($cl['created_at'])) ?></td>
                                    <td>
                                        <a href="item-detail.php?id=<?= $cl['item_id'] ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
