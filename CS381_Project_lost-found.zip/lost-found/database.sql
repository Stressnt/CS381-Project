-- ============================================================
--  YIC Lost & Found Portal  –  Database Schema & Seed Data
--  CS381 / CS472  Web Application Development Project
-- ============================================================

CREATE DATABASE IF NOT EXISTS yic_lost_found
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE yic_lost_found;

-- ─────────────────────────────────────────
--  USERS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)        NOT NULL,
    email       VARCHAR(150)        NOT NULL UNIQUE,
    password    VARCHAR(255)        NOT NULL,
    role        ENUM('student','admin') NOT NULL DEFAULT 'student',
    phone       VARCHAR(20)         DEFAULT NULL,
    created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
--  ITEMS  (lost or found)
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS items (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED        NOT NULL,
    type            ENUM('lost','found') NOT NULL,
    title           VARCHAR(150)        NOT NULL,
    description     TEXT                NOT NULL,
    category        VARCHAR(60)         NOT NULL,
    location        VARCHAR(150)        NOT NULL,
    date_occurred   DATE                NOT NULL,
    image           VARCHAR(255)        DEFAULT NULL,
    status          ENUM('active','claimed','closed') NOT NULL DEFAULT 'active',
    created_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
--  CLAIMS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS claims (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_id         INT UNSIGNED        NOT NULL,
    claimant_id     INT UNSIGNED        NOT NULL,
    message         TEXT                NOT NULL,
    status          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    admin_note      TEXT                DEFAULT NULL,
    created_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id)      REFERENCES items(id)  ON DELETE CASCADE,
    FOREIGN KEY (claimant_id)  REFERENCES users(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
--  NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED    NOT NULL,
    message     TEXT            NOT NULL,
    link        VARCHAR(255)    DEFAULT NULL,
    is_read     TINYINT(1)      NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
--  SEED DATA
-- ─────────────────────────────────────────

-- Passwords are bcrypt of "Password123"
INSERT INTO users (name, email, password, role, phone) VALUES
('Admin YIC',        'admin@yic.edu.sa',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'admin',   '0500000001'),
('Ahmed Al-Ghamdi',  'ahmed@yic.edu.sa',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0512345678'),
('Sara Al-Zahrani',  'sara@yic.edu.sa',     '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0523456789'),
('Omar Al-Harbi',    'omar@yic.edu.sa',     '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0534567890'),
('Fatima Al-Otaibi', 'fatima@yic.edu.sa',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0545678901'),
('Khaled Al-Dosari', 'khaled@yic.edu.sa',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0556789012'),
('Noura Al-Mutairi', 'noura@yic.edu.sa',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0567890123'),
('Faisal Al-Qahtani','faisal@yic.edu.sa',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0578901234'),
('Hanan Al-Shehri',  'hanan@yic.edu.sa',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0589012345'),
('Bader Al-Anazi',   'bader@yic.edu.sa',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0590123456'),
('Reem Al-Balawi',   'reem@yic.edu.sa',     '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uHxF9jhmW', 'student', '0501234567');

-- Password note: all sample passwords are "password" (Laravel-style hash used above is for "password")
-- For testing use: admin@yic.edu.sa / Password123  OR  ahmed@yic.edu.sa / Password123

INSERT INTO items (user_id, type, title, description, category, location, date_occurred, status) VALUES
(2, 'lost',  'Black Laptop Bag',          'A black Dell laptop bag with a red zip. Contains charger and notebooks inside.', 'Bags',        'Library – 2nd Floor',          '2026-05-01', 'active'),
(3, 'found', 'Samsung Galaxy S23',        'Found a black Samsung phone near the canteen. Screen has a small crack at corner.', 'Electronics', 'Canteen Area',                 '2026-05-02', 'active'),
(4, 'lost',  'Student ID Card',           'Lost my YIC student ID. Name: Omar Al-Harbi, ID number visible on card.', 'ID / Cards',  'Engineering Building – Room 204','2026-05-03', 'active'),
(5, 'found', 'Blue Water Bottle',         'Found a blue Thermos water bottle with YIC sticker on it near the gym entrance.', 'Accessories', 'Sports Hall – Entrance',       '2026-05-04', 'active'),
(6, 'lost',  'Scientific Calculator',     'Casio fx-991ES PLUS, black with silver buttons. Name written inside the battery cover.', 'Electronics', 'Math Lab',                 '2026-05-05', 'active'),
(7, 'found', 'Car Keys – Toyota',         'Found Toyota car keys with a green keychain in the parking lot near Gate 2.', 'Keys',        'Parking Lot – Gate 2',         '2026-05-06', 'active'),
(8, 'lost',  'Gold Wristwatch',           'A gold-coloured Casio watch lost in the sports hall during basketball practice.', 'Accessories', 'Sports Hall',                  '2026-05-07', 'active'),
(9, 'found', 'Engineering Textbook',      'Found "Engineering Mathematics" textbook. Owner name written as F. Al-Qahtani inside front cover.', 'Books', 'Cafeteria – Table 5', '2026-05-08', 'active'),
(10,'lost',  'Wireless Earbuds (AirPods)','White Apple AirPods Pro in white case. Last seen in the library study room.', 'Electronics', 'Library – Study Room 3',       '2026-05-09', 'active'),
(11,'found', 'Red Umbrella',              'Found a red umbrella near the main entrance. Has a curved wooden handle.', 'Accessories', 'Main Entrance',                 '2026-05-10', 'active'),
(2, 'lost',  'USB Flash Drive 32GB',      'Black SanDisk USB drive with sticker of Saudi flag. Contains important project files.', 'Electronics', 'Computer Lab B12',        '2026-05-11', 'active'),
(3, 'found', 'Prescription Glasses',      'Found black-framed reading glasses in a brown leather case near Room 115.', 'Accessories', 'Building A – Room 115',        '2026-05-12', 'active');

INSERT INTO claims (item_id, claimant_id, message, status) VALUES
(3, 2, 'I believe this is my phone. My screen has a crack at the bottom-right corner and my wallpaper is a mountain landscape.', 'pending'),
(7, 8, 'These are my Toyota keys. I can describe the exact model and provide my vehicle registration.', 'pending'),
(9, 8, 'That textbook is mine! You can see my name F. Al-Qahtani written inside. I lost it on May 8th.', 'approved');

INSERT INTO notifications (user_id, message, link, is_read) VALUES
(2, 'Your claim for "Samsung Galaxy S23" has been submitted and is pending admin review.', 'item-detail.php?id=3', 0),
(8, 'Your claim for "Engineering Textbook" has been approved! Please visit the admin office to collect it.', 'item-detail.php?id=9', 0),
(8, 'Your claim for "Car Keys – Toyota" has been submitted and is pending admin review.', 'item-detail.php?id=7', 1),
(3, 'Someone has claimed your found item "Samsung Galaxy S23". Please check the admin panel.', 'item-detail.php?id=3', 0);
